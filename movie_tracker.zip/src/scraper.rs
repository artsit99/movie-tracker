use scraper::{ElementRef, Html, Selector};
use reqwest::redirect;
use std::collections::HashSet;
use std::sync::RwLock;

/// Movie structures for seeding data
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct Movie {
    pub title: String,
    pub year: u16,
    pub wiki_url: String,
}

/// Cleaner for Wikipedia movie titles
fn clean_movie_title(raw_title: &str) -> String {
    if raw_title.trim().is_empty() {
        return String::new();
    }

    // Remove Wikipedia reference footnotes like [1], [a], etc.
    let cleaned = regex::Regex::new(r"\[\d+|[a-z]+\]").unwrap().replace(raw_title, "");

    // Remove quotes surrounding title
    let cleaned = cleaned.trim_matches([' ', '"', '\'', '“', '”', '«', '»']);

    // Strip trailing disambiguations like "(film)", "(2000 film)"
    let cleaned = regex::Regex::new(r"\s*\((?:film|\d{4}\s+film|\d{4})\)")
        .unwrap()
        .replace(&cleaned, "");

    // Replace weird whitespace with single space
    let cleaned = regex::Regex::new(r"\s+").unwrap().replace(&cleaned, " ");

    cleaned.trim().to_string()
}

/// Scrape Wikipedia for movies of a specific year
/// URL format: https://en.wikipedia.org/wiki/List_of_American_films_of_2000
pub async fn scrape_year(year: u16) -> Result<Vec<Movie>, Box<dyn std::error::Error>> {
    let url = format!("https://en.wikipedia.org/wiki/List_of_American_films_of_{}", year);
    
    let client = reqwest::Client::builder()
        .user_agent("Mozilla/5.0 (compatible; MovieTrackerBot/1.0)")
        .follow_redirects(true)
        .build()?;
    
    let response = client.get(&url).send().await?;
    let html = response.text().await?;
    
    let document = Html::parse_document(&html);
    
    // Wikipedia uses different table classes per year (wikitable, vi deserving-entry, infobox v2)
    let table_selectors = vec![
        Selector::parse(".wikitable tbody tr").unwrap(),
        Selector::parse("table tbody tr").unwrap(),
    ];
    
    let mut movies = Vec::new();
    let seen = RwLock::new(HashSet::new());
    
    for selector in &table_selectors {
        for element in document.select(selector) {
            // Extract the first cell (title)
            if let Some(first_cell) = element.select(&Selector::parse("th, td").unwrap()).next() {
                if let Some(title_cell) = first_cell.select(&Selector::parse("a").unwrap()).next() {
                    let title = clean_movie_title(title_cell.text().collect::<String>().as_str());
                    let year_str = title_cell
                        .parent()
                        .and_then(|parent| parent.select(&Selector::parse("td").unwrap()).nth(1))
                        .and_then(|cell| cell.text().next())
                        .and_then(|year_cell| year_cell.trim().parse::<u16>().ok());
                    
                    if !title.is_empty() && year_str == Some(year) {
                        let key = (title.clone(), year);
                        let is_new_movie = {
                            let mut seen_guard = seen.write().unwrap();
                            !seen_guard.insert(key.clone())
                        };
                        
                        if is_new_movie {
                            let wiki_url = title_cell.value().attr("href")
                                .map(|href| format!("https://en.wikipedia.org/{}", href))
                                .unwrap_or_else(|| url.clone());
                            
                            movies.push(Movie {
                                title,
                                year,
                                wiki_url,
                            });
                        }
                    }
                }
            }
        }
        if !movies.is_empty() {
            break;
        }
    }
    
    Ok(movies)
}

/// Recursive scraper that fetches data for a year range
pub async fn scrape_range(start_year: u16, end_year: u16) -> Result<Vec<Movie>, Box<dyn std::error::Error>> {
    let mut all_movies = Vec::new();
    
    for year in start_year..=end_year {
        println!("Scraping {}...", year);
        match scrape_year(year).await {
            Ok(year_movies) => {
                all_movies.extend(year_movies);
                println!("Found {} movies for {}", year_movies.len(), year);
            }
            Err(e) => {
                eprintln!("Failed to scrape {}: {}", year, e);
            }
        }
        
        // Small delay to be polite
        tokio::time::sleep(std::time::Duration::from_millis(200)).await;
    }
    
    Ok(all_movies)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_scrape_2020() {
        let movies = scrape_year(2020).await.unwrap();
        println!("Found {} movies", movies.len());
        assert!(!movies.is_empty());
    }

    #[test]
    fn test_clean_title() {
        assert_eq!(clean_movie_title("Toy Story (1995 film)"), "Toy Story");
        assert_eq!(clean_movie_title("The Shawshank Redemption [1]"), "The Shawshank Redemption");
    }
}
