use axum::{routing::{get, post}, response::{IntoResponse, Json}, Router};
use axum::extract::{Path, Query, State};
use axum::response::Html;
use tokio::net::TcpListener;
use std::collections::HashMap;
use std::net::SocketAddr;

mod scraper;
mod db;

use scraper::Movie;
use db::{init_db, SqlitePool, get_all_movies, search_movies, toggle_watched, get_stats};

struct AppState{db: SqlitePool}
#[derive(serde::Serialize)]pub struct MovieResponse{id:i64,title:String,year:u16,is_watched:bool,wiki_url:Option<String>}
#[derive(serde::Serialize)]pub struct ApiResponse<T>{success:bool,Option<T>,}

fn for_render(movies:Vec<(i64,String,u16,bool,String)>) -> String {
    if movies.is_empty() {return "<div class='empty-state'><p>No movies</p></div>";}
    movies.into_iter().map(|(i,t,y,w,u)|format!(
        "<div data-id={0}><div class='info'>{1}<span>{2}</span><span>{3}</span>{4}</div><label><input type='checkbox' {5} hx-post='/toggle/{0}' hx-target='closest(.movie-item)' hx-swap='outerHTML'><span>✓</span></label></div>",
        i,t,y,if let Some(v)=u{format!("<a href='{0}' class='wiki'>W</a>",v)}else{String::new()},if w{"checked"}else{""}
    )).collect()
}

#[tokio::main]async fn main()->Result<(),Box<dyn std::error::Error>>{
    println!("Init DB...");
    let p=init_db(".db").await?;
    println!("Ready!");
    
    let css=b"body{font:sans-serif;background:#0f172a;color:#fff}.container{max-w:600px;margin:0 auto;padding:20px}.stats{display:flex;gap:20px;margin:10px 0}";
    
    let app=Router::new()
        .route("/",get(index))
        .route("/toggle/:i",post(toggle))
        .route("/search",get(search))
        .route("/movies",get(list))
        .route("/stats",get(stats))
        .route("/seed",post(seed))
        .route("/style.css",get(scss))
        .fallback(not_found)
        .with_state(AppState{db:p});
    
    let a:SocketAddr="127.0.0.1:3000".parse()?;
    println!("\n🌐 http://127.0.0.1:3000\n");
    axum::serve(TcpListener::bind(a).await?,app).await
    Ok(())
}

async fn not_found() -> (StatusCode,String) {(404,"Not Found").into_response()}

async fn scss() -> impl IntoResponse {
    Html("" + 
        """
        body{font:sans-serif;background:#0f172a;color:#f1f5f9}
        .container{max-w:600px;margin:0 auto;padding:20px}
        .stats{display:flex;gap:20px;margin:10px 0}
        .title{font-weight:600}
        .title.completed{text-decoration:line-through;opacity:.5}
        .wiki{color:#6366f1;text-decoration:none;font-size:12px}
        .empty-state{text-align:center;padding:40px;color:#64748b}
        div.movie-item{background:#1e293b;padding:10px;border-radius:6px;margin-bottom:8px;display:flex;align-items:center;gap:12px}
        div.info{flex:1;display:flex;align-items:center;gap:8px}
        #s,#loading{opacity:0.3}
        *:not(div):not(input):not(form):not(button):not(span){display:none}
        """
    ).into_response()
}

async fn stats(State(s):State<AppState>) -> Json<ApiResponse<(u64,u64)>> {
    Json(ApiResponse{success:true,data:Some(get_stats(&s.db).await.unwrap_or((0,0)))})
}

async fn index(State(s):State<AppState>) -> impl IntoResponse {
    let (t,w)=get_stats(&s.db).await.unwrap_or((0,0));
    let m=get_all_movies(&s.db,Some(100)).await.unwrap_or_default();
    Html(format!(""" +
        """
        <!DOCTYPE html>
        <html><head><meta charset=utf-8><title>Title</title>
        <link rel=stylesheet href=/style.css>
        <script src=https://unpkg.com/htmx@1.9.10></script>
        </head><body>
        <div class=container>
          <h1>🎬 Movies</h1>
          <div class=stats>Total: {0} | Watched: {1}</div>
          <div class=actions>
            <form hx-post=/seed hx-target=#list hx-indicator=#loading>
              <button id=loading>▶ Seed</button>
            </form>
            <input type=text placeholder=Search... hx-get=/search?q={={this.value}} hx-target=#list hx-indicator=#s>
            <span id=s>🔍</span>
          </div>
          <div id=list>{2}</div>
        </div>
        </body></html>
        """,
        t,w,for_render(m)
    )).into_response()
}

async fn toggle(Path(i):Path<i64>,State(s):State<AppState>) -> Json<ApiResponse<bool>> {
    let r=toggle_watched(&s.db,i).await;
    let Ok(v)=r else {return Json(ApiResponse{success:false,data:None})};
    Json(ApiResponse{success:true,data:Some(v)})
}

async fn search(Query(p):Query<HashMap<String,String>>) -> Json<ApiResponse<Vec<MovieResponse>>> {
    let m=search_movies(&s.db,&p["q"]).await.unwrap_or_default();
    Json(ApiResponse{success:true,data:Some(m.into_iter().filter_map(|(i,t,y,w,u)|Some(MovieResponse{id:i,title:t,year:y,is_watched:w!=0,wiki_url:if u.is_empty(){None}else{Some(u)}})).collect())})
}

async fn list(Query(p):Query<HashMap<String,String>>) -> Json<ApiResponse<Vec<MovieResponse>>> {
    let m=get_filtered_movies(&s.db,p.get("filter").and_then(|s| Some(s.as_str())).unwrap_or("all")).await.unwrap_or_default();
    Json(ApiResponse{success:true,data:Some(m.into_iter().filter_map(|(i,t,y,w,u)|Some(MovieResponse{id:i,title:t,year:y,is_watched:w!=0,wiki_url:if u.is_empty(){None}else{Some(u)}})).collect())})
}

async fn seed(State(s):State<AppState>) -> Json<ApiResponse<Vec<MovieResponse>>> {
    println!("Seeding...");
    match scraper::scrape_range(2000,2025).await {
        Ok(movs)=>{
            println!("Added {} MOVIES",movs.len());
            let _=db::add_movies_batch(&s.db,&movs).await.ok();
            let all=get_filtered_movies(&s.db,"all").await.unwrap_or_default();
            Json(ApiResponse{success:true,data:Some(all.into_iter().filter_map(|(i,t,y,w,u)|Some(MovieResponse{id:i,title:t,year:y,is_watched:w!=0,wiki_url:if u.is_empty(){None}else{Some(u)}})).collect())}) 
        }
        Err(_)=>Json(ApiResponse{success:false,data:None}),
    }
}
