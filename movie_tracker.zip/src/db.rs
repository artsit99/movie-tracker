use sqlx::{SqlitePool, Row, Result as SqlxResult};
use crate::scraper::Movie;

pub async fn init_db(db_path: &str) -> SqlxResult<SqlitePool> {
    let pool = SqlitePool::connect(db_path).await?;
    
    sqlx::query(
        "CREATE TABLE IF NOT EXISTS movies (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, year INTEGER NOT NULL, is_watched INTEGER DEFAULT 0, wiki_url TEXT)"
    ).execute(&pool).await?;
    
    sqlx::query("CREATE INDEX IF NOT EXISTS idx_movies_year ON movies(year)").execute(&pool).await?;
    sqlx::query("CREATE INDEX IF NOT EXISTS idx_movies_watched ON movies(is_watched)").execute(&pool).await?;
    sqlx::query("CREATE INDEX IF NOT EXISTS idx_movies_title ON movies(title)").execute(&pool).await?;
    
    Ok(pool)
}

pub async fn add_movie(pool: &SqlitePool, movie: &Movie) -> SqlxResult<sqlx::sqlite::SqliteQueryResult> {
    sqlx::query("INSERT OR IGNORE INTO movies (title, year, wiki_url) VALUES (?, ?, ?)")
        .bind(&movie.title)
        .bind(movie.year as i64)
        .bind(&movie.wiki_url)
        .execute(pool).await
}

pub async fn add_movies_batch(pool: &SqlitePool, movies: &[Movie]) -> SqlxResult<(u64, u64)> {
    let mut count = 0u64;
    for movie in movies {
        match add_movie(pool, movie).await {
            Ok(result) if result.rows_affected() > 0 => count += 1,
            _ => {}
        }
    }
    Ok((movies.len() as u64, count))
}

pub async fn get_all_movies(pool: &SqlitePool, limit: Option<usize>) -> SqlxResult<Vec<(i64, String, u16, bool, String)>> {
    let mut query = sqlx::query("SELECT id, title, year, is_watched, wiki_url FROM movies ORDER BY year DESC, title ASC");
    if let Some(l) = limit { query = query.limit(l as u64); }
    query.fetch_all(pool).await
}

pub async fn search_movies(pool: &SqlitePool, query: &str) -> SqlxResult<Vec<(i64, String, u16, bool, String)>> {
    let search_pattern = format!("%{}%", query);
    sqlx::query("SELECT id, title, year, is_watched, wiki_url FROM movies WHERE title LIKE ? ORDER BY is_watched ASC, year DESC, title ASC")
        .bind(&search_pattern).fetch_all(pool).await
}

pub async fn toggle_watched(pool: &SqlitePool, id: i64) -> SqlxResult<bool> {
    let row = sqlx::query("SELECT is_watched FROM movies WHERE id = ?").bind(id).fetch_one(pool).await?;
    let is_watched: i32 = row.get("is_watched");
    let new_status = if is_watched == 0 { 1 } else { 0 };
    sqlx::query("UPDATE movies SET is_watched = ? WHERE id = ?").bind(new_status).bind(id).execute(pool).await?;
    Ok(new_status == 1)
}

pub async fn get_stats(pool: &SqlitePool) -> SqlxResult<(u64, u64)> {
    let total: u64 = sqlx::query_scalar("SELECT COUNT(*) FROM movies").fetch_one(pool).await?;
    let watched: u64 = sqlx::query_scalar("SELECT COUNT(*) FROM movies WHERE is_watched = 1").fetch_one(pool).await?;
    Ok((total, watched))
}

pub async fn get_filtered_movies(pool: &SqlitePool, filter: &str) -> SqlxResult<Vec<(i64, String, u16, bool, String)>> {
    match filter.to_lowercase().as_str() {
        "watched" => sqlx::query("SELECT id, title, year, is_watched, wiki_url FROM movies WHERE is_watched = 1 ORDER BY title ASC").fetch_all(pool).await,
        "unwatched" => sqlx::query("SELECT id, title, year, is_watched, wiki_url FROM movies WHERE is_watched = 0 ORDER BY title ASC").fetch_all(pool).await,
        _ => sqlx::query("SELECT id, title, year, is_watched, wiki_url FROM movies ORDER BY is_watched ASC, year DESC, title ASC").fetch_all(pool).await,
    }
}
